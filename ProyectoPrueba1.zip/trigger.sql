use vuelos;

delimiter !

CREATE TRIGGER auto_instancia_vuelo 
AFTER INSERT ON salidas
FOR EACH ROW
BEGIN
	declare fechaInicio DATE;
	declare fechaFin DATE;
	declare offset INT; 
	
	set fechaInicio= CURDATE();
	
	set offset=ABS(NEW.dia - DAYOFWEEK(fechaInicio));
	IF (DAYOFWEEK(fechaInicio) <> NEW.dia) THEN
		SELECT DATE_ADD(fechaInicio,INTERVAL (offset) DAY) INTO fechaInicio;
	END IF;
	
	set fechaFin = (SELECT DATE_ADD(fechaInicio,INTERVAL 1 YEAR));
	WHILE (DATEDIFF(fechaFin,fechaInicio)>0) DO
		INSERT INTO instancias_vuelo( vuelo, fecha, dia, estado) VALUES (NEW.vuelo,fechaInicio,NEW.dia,'a tiempo');
		SELECT DATE_ADD(fechaInicio,INTERVAL 7 DAY) INTO fechaInicio;
	END WHILE;

END; !
delimiter ;